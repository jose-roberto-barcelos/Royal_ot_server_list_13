import os
import subprocess
from flask import Flask, jsonify

app = Flask(__name__)


@app.route("/", methods=["GET"])
def run_tasks():
    try:
        # executa seus scripts (coleta + ranking)
        subprocess.run(["./run_all.sh"], check=True)
        return jsonify({"status": "ok"}), 200
    except subprocess.CalledProcessError as e:
        return jsonify({"status": "error", "detail": str(e)}), 500


if __name__ == "__main__":
    # lê a porta que o Cloud Run define (padrão 8080)
    port = int(os.environ.get("PORT", "8080"))
    app.run(host="0.0.0.0", port=port)
