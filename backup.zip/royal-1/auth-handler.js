// auth-handler.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";

// Configuração Firebase (mesma que já está usando)
const firebaseConfig = {
  apiKey: "AIzaSyBnzTkzA4KsbvUruYobVEsWFP_upCFGvFM",
  authDomain: "royalotservlist.firebaseapp.com",
  projectId: "royalotservlist",
  storageBucket: "royalotservlist.firebasestorage.app",
  messagingSenderId: "795611612401",
  appId: "1:795611612401:web:3f869dcdff2366a0b45550",
  measurementId: "G-LP54JFLRDT"
};

initializeApp(firebaseConfig);
const auth = getAuth();

window.addEventListener("DOMContentLoaded", () => {
  const loginBtn     = document.querySelector(".login-btn");
  const loginImg     = loginBtn.querySelector("img");
  const registrarBtn = document.querySelector(".registrar-btn");

  // 1) Garante ação de Login mesmo antes do callback
  loginBtn.addEventListener("click", () => {
    window.location.href = "login.html";
  });
  // Garante ação padrão do Registrar
  registrarBtn.addEventListener("click", () => {
    window.location.href = "register.html";
  });

  // 2) Depois que souber o estado de auth, sobrescreve para logout
  onAuthStateChanged(auth, (user) => {
    if (user) {
      // usuário logado → muda ícone e faz logout
      loginImg.src = "./icon-sair.png";
      loginImg.alt = "Sair";
      loginBtn.onclick = () => {
        signOut(auth).then(() => {
          alert("Deslogado com sucesso.");
          window.location.reload();
        });
      };
      // Registrar passa a ir direto pra aba servidor
      registrarBtn.onclick = () => {
        window.location.href = "register.html?aba=servidor";
      };
    } else {
      // se deslogado, deixamos o listener do addEventListener ativo
      // e restauramos o ícone/via src
      loginImg.src = "./icon-login.png";
      loginImg.alt = "Login";
      // registrarBtn já navega para 'register.html'
    }
  });
});
