import {
    getAuth,
    signInWithEmailAndPassword,
  } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
  
  const firebaseConfig = {
    apiKey: "AIzaSyBnzTkzA4KsbvUruYobVEsWFP_upCFGvFM",
    authDomain: "royalotservlist.firebaseapp.com",
    projectId: "royalotservlist",
    storageBucket: "royalotservlist.firebasestorage.app",
    messagingSenderId: "795611612401",
    appId: "1:795611612401:web:3f869dcdff2366a0b45550",
    measurementId: "G-LP54JFLRDT",
  };
  
  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);
  
  document.getElementById("form-login").addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
  
    signInWithEmailAndPassword(auth, email, senha)
      .then(() => {
        alert("Login realizado com sucesso!");
        window.location.href = "painel.html";
      })
      .catch((error) => {
        alert("Erro ao logar: " + error.message);
      });
  });
  