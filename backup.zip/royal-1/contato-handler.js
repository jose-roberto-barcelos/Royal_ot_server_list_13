// contato-handler.js
console.log("🚀 contato-handler.js carregado");

import { db } from "./firebase-config.js";
import {
  collection,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", () => {
  console.log("📄 contato-handler: DOM pronto");
  const form = document.getElementById("contato-form");
  if (!form) return console.error("❌ contato-handler: #contato-form não encontrado");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    console.log("✉️ contato-handler: submit capturado");

    const data = {
      nome:      form.nome.value,
      email:     form.email.value,
      mensagem:  form.mensagem.value,
      criadoEm:  serverTimestamp()
    };
    console.log("📤 contato-handler: enviando", data);

    try {
      const ref = await addDoc(collection(db, "contatos"), data);
      console.log("✅ contato-handler: documento criado com ID", ref.id);
      alert("Mensagem enviada com sucesso!");
      form.reset();
    } catch (err) {
      console.error("❌ contato-handler: erro ao gravar", err);
      alert("Erro ao enviar mensagem. Veja o console.");
    }
  });
});
