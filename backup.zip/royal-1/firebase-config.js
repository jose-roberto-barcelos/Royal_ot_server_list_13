// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import {
  getFirestore
} from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "",
  authDomain: "royalotservlist.firebaseapp.com",
  projectId: "royalotservlist",
  storageBucket: "royalotservlist.firebasestorage.app",
  messagingSenderId: "795611612401",
  appId: "1:795611612401:web:3f869dcdff2366a0b45550",
  measurementId: "G-LP54JFLRDT"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
