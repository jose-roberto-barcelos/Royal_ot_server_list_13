#!/bin/sh
# 1) Vai para a pasta do backend
cd backend

# 2) Executa coleta e ranking
python coleta_validada_pronto.py
python gerar_ranking_ordenado.py

# 3) Faz upload do CSV para o bucket usando Python
python - <<'EOF'
from google.cloud import storage
import os

# Nome do bucket
bucket_name = "royalotservlist-rankings"
# Caminho local do CSV de saída
local_file = "ranking_final.csv"
# Nome do objeto no bucket
dest_blob = "ranking_final.csv"

client = storage.Client()
bucket = client.bucket(bucket_name)
blob = bucket.blob(dest_blob)
blob.upload_from_filename(local_file, content_type="text/csv")
print("🚀 CSV enviado para gs://%s/%s" % (bucket_name, dest_blob))
EOF
