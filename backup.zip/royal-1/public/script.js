document.addEventListener("DOMContentLoaded", () => {
  // Array que guarda todos os servidores lidos do CSV
  let servidores = [];
  // Guarda qual coluna está ordenada e a direção
  let ordemAtual = { coluna: null, crescente: true };

  // 1) Busca o CSV gerado pelo Python
  fetch("ranking_final.csv")
    .then((res) => res.text())
    .then((text) => {
      // 2) Converte o CSV em array de objetos
      const linhas = text.trim().split("\n");
      const headers = linhas.shift().split(",");
      servidores = linhas.map((linha) => {
        const cols = linha.split(",");
        const obj = {};
        headers.forEach((h, i) => {
          let v = cols[i] || "";
          // Converte números nas colunas específicas
          if (h === "Jogadores Online" || h === "Versão") {
            v = parseFloat(v) || 0;
          }
          obj[h] = v;
        });
        return obj;
      });
      // 3) Liga os cliques nos <th> à ordenação
      setupSorting(headers);
      // 4) Renderiza a tabela inicialmente
      renderTabela(servidores);
    })
    .catch((err) => console.error("Erro ao carregar CSV:", err));

  // Função que configura os headers clicáveis
  function setupSorting(headers) {
    document.querySelectorAll("th").forEach((th) => {
      // Extrai o texto do <th> e limpa ícones
      const coluna = th.textContent.replace(/ ⬍|⇵|⬌/g, "").trim();
      // Só adiciona evento se essa coluna existir no CSV
      if (headers.includes(coluna)) {
        th.style.cursor = "pointer"; // mostra que é clicável
        th.addEventListener("click", () => {
          ordenarPor(coluna);
        });
      }
    });
  }

  // Função que ordena o array e re-renderiza
  function ordenarPor(coluna) {
    // Se clicar na mesma coluna troca a direção
    if (ordemAtual.coluna === coluna) {
      ordemAtual.crescente = !ordemAtual.crescente;
    } else {
      ordemAtual = { coluna, crescente: true };
    }
    const isNum = coluna === "Jogadores Online" || coluna === "Versão";
    servidores.sort((a, b) => {
      let aV = a[coluna],
        bV = b[coluna];
      if (isNum) {
        aV = aV || 0;
        bV = bV || 0;
      } else {
        aV = String(aV).toLowerCase();
        bV = String(bV).toLowerCase();
      }
      if (aV < bV) return ordemAtual.crescente ? -1 : 1;
      if (aV > bV) return ordemAtual.crescente ? 1 : -1;
      return 0;
    });
    renderTabela(servidores);
  }

  // Função que renderiza um array na <tbody>
  function renderTabela(dados) {
    const tbody = document.getElementById("tabela-servidores");
    tbody.innerHTML = ""; // limpa linhas antigas
    dados.forEach((s) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${s["Servidor"]}</td>
        <td>${s["Versão"]}</td>
        <td>${s["Jogadores Online"]}</td>
        <td>${s["Origem"]}</td>
        <td>${s["Observação"] || "-"}</td>
      `;
      tbody.appendChild(tr);
    });
  }
});
